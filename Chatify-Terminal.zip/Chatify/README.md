# Chatify
Chatify is a term chat application developed as part of Assignment-2 of COL334: Computer Networks. <br />
It uses sockets to establish connections between clients and server.
# How to run
The machine should satisfy the following requirements:
- Machine should have python3 installed.
- colorama and pyfiglet are the two external libraries used. Use the command `pip install -r requirements.txt` to download all the required libraries.
- Running server application: Use `python3 server.py` to run the server side application.
- Running client application: Use `python3 client.py` to run the client side application.


